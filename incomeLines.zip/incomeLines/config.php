<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'wealth_creation_erp');

// Application settings
define('APP_NAME', 'Wealth Creation ERP');
define('WC_BEGIN_TIME', '16:30:00');
define('WC_END_TIME', '23:59:59');

// Set timezone
date_default_timezone_set('Africa/Lagos');
?>